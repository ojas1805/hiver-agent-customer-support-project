# Model and Data Artifacts

The GitHub-friendly source package intentionally excludes large binary/data files.

## Excluded artifacts

- models/distilbert_intent_classifier/model.safetensors
- models/retrieval_embeddings.npy
- data/processed/apple_support_pairs.csv

## Why

These artifacts make the complete project archive approximately 709 MB.
They are therefore excluded from normal source-control submission.

The complete local package contains these files.

## Rebuilding

DistilBERT model:
The packaged trained model can be placed at:

models/distilbert_intent_classifier/

Retrieval embeddings:

python src/replies/build_index.py

This regenerates:

models/retrieval_embeddings.npy

Historical AppleSupport data:

data/processed/apple_support_pairs.csv
