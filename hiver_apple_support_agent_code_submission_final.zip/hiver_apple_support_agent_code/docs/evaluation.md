# Evaluation

## Dataset
Historical AppleSupport pairs: 104,409
Strong silver examples: 3,415
Clean leakage-free development evaluation: 110

## Classification

| System | Accuracy | Macro F1 | Weighted F1 |
|---|---:|---:|---:|
| TF-IDF + Logistic Regression | 90.63% | 90.06% | 90.70% |
| DistilBERT + rules | 90.91% | 90.50% | 90.50% |
| Zero-Shot Groq | 77.27% | 71.30% | 77.78% |

DistilBERT silver validation:
Accuracy 94.29%
Macro F1 93.67%
Weighted F1 94.25%

## Baseline improvement
Accuracy improvement over zero-shot Groq: 13.64 percentage points.
Macro F1 improvement: 19.20 percentage points.

## Retrieval
Average top-1 similarity: 0.8146.
All 110 clean evaluation cases crossed the STRONG threshold after exact self-match exclusion.
This is similarity, not retrieval accuracy.

## Response evaluation
20 representative cases were tested.
Valid responses: 6
Invalid or empty: 14
Validity: 30%

## LLM-as-judge
Six valid responses were judged.
Groundedness: 5.00 / 5
Helpfulness: 4.67 / 5
Tone: 5.00 / 5
Safety: 5.00 / 5
Overall: 5.00 / 5

## Escalation
Final system: 87 auto-handled and 23 escalated.
Zero-shot baseline: 96 auto-handled and 14 escalated.

## Limitations
The clean evaluation is semantic rather than fully human labeled.
information_or_how_to has no examples in the clean evaluation.
The human-checked golden set contains only 19 usable examples.