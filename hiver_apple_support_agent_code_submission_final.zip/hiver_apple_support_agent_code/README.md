# Hiver AI Support Agent — AppleSupport

AI support agent built for the Hiver take-home assignment using the Customer Support on Twitter dataset.

## Overview

The agent:
1. Classifies customer messages into 12 support intents.
2. Retrieves similar historical AppleSupport conversations.
3. Generates a grounded reply using Groq.
4. Decides whether to auto-handle or escalate.

## Architecture

Customer Message
→ DistilBERT + rules
→ MiniLM historical retrieval
→ Grounded Groq response
→ Escalation policy
→ Auto-handle / Escalate

## Intent Taxonomy

- ios_update_issue
- app_crash_or_freeze
- device_performance
- battery_issue
- connectivity_issue
- media_playback_issue
- authentication_or_code
- hardware_repair_or_damage
- system_ui_keyboard_or_notification_bug
- icloud_photos_or_mail
- messaging_or_communication
- information_or_how_to

Definitions are in src/intents/intent_definitions.py.

## Dataset

Brand: AppleSupport

AppleSupport rows: 106,860
Usable customer-to-brand pairs: 104,409
Strong silver examples: 3,415
Clean evaluation examples: 110

## Classification

Primary classifier: DistilBERT.

Silver validation:

| Model | Accuracy | Macro F1 | Weighted F1 |
|---|---:|---:|---:|
| TF-IDF + Logistic Regression | 90.63% | 90.06% | 90.70% |
| DistilBERT | 94.29% | 93.67% | 94.25% |

Leakage-free development evaluation:

| Model | Accuracy | Macro F1 | Weighted F1 |
|---|---:|---:|---:|
| Zero-Shot Groq | 77.27% | 71.30% | 77.78% |
| DistilBERT + rules | 90.91% | 90.50% | 90.50% |

Accuracy improvement over zero-shot baseline: 13.64 percentage points.

Note: the clean evaluation is a semantic development evaluation, not a fully human-labeled benchmark.

## Retrieval

Model: sentence-transformers/all-MiniLM-L6-v2

Top 3 historical examples are retrieved using normalized cosine similarity.

Thresholds:
- STRONG >= 0.60
- MEDIUM >= 0.45
- WEAK < 0.45

Average top-1 similarity: 0.8146.

This represents similarity, not retrieval accuracy.

## Grounded Response Generation

Provider: Groq
Model: openai/gpt-oss-120b

The generator is instructed to use only historical AppleSupport evidence and avoid unsupported policies, refunds, prices, timelines, guarantees, diagnoses, and troubleshooting claims.

Empty or incomplete responses are rejected.

## Response Evaluation

20 representative cases were tested.

Valid responses: 6
Invalid or empty responses: 14
Validity: 30%

LLM-as-judge on the 6 valid responses:

| Dimension | Average |
|---|---:|
| Groundedness | 5.00 / 5 |
| Helpfulness | 4.67 / 5 |
| Tone | 5.00 / 5 |
| Safety | 5.00 / 5 |
| Overall | 5.00 / 5 |

The sample is small.

## Escalation

The final policy considers:
- low intent confidence
- weak historical evidence
- authentication/account issues
- invalid or unavailable responses
- conservative fallback behavior

Final system:
- Auto-handle: 87 / 110 (79.09%)
- Escalate: 23 / 110 (20.91%)

## Required Baseline

Zero-shot Groq baseline:
- Accuracy: 77.27%
- Macro F1: 71.30%
- Weighted F1: 77.78%

Baseline escalation:
- Auto-handle: 96 / 110 (87.27%)
- Escalate: 14 / 110 (12.73%)

## Golden Set

The assignment requests 150–250 hand-labeled examples.

Current usable human-checked examples: 19.

This repository does not claim that 19 examples satisfy the requested golden-set size.

## Known Limitations

1. The golden set is below the requested 150–250 examples.
2. The clean evaluation is semantic rather than fully human labeled.
3. information_or_how_to has zero examples in the clean evaluation.
4. Response validity was only 30% on the 20-case sample.
5. LLM-as-judge used only 6 valid responses.
6. Retrieval is currently implemented with MiniLM embeddings and NumPy similarity.
7. A separate optional Groq risk-check pass was not included.

## Running

Install:

pip install -r requirements.txt

Set the Groq key:

export GROQ_API_KEY='YOUR_KEY'

Build embeddings:

python src/replies/build_index.py

Run:

python pipeline.py